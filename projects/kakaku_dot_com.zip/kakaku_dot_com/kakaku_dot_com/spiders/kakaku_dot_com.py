import scrapy
import re
from kakaku_dot_com.items import KakakuDotComItem

class KakakuDotComSpider(scrapy.Spider):

    name = 'kakaku_dot_com'
    allowed_domains = ['kakaku.com']
    start_urls = ['https://kakaku.com/item/J0000031201/']

    def parse(self, response):

        """ start_urlに指定した商品の最安値を取得する。  """

        item = KakakuDotComItem('')

        item['product_id'] = re.search(r'item\/(\w+)', response.url).group(1)
        item['product_name'] = response.css('div.itmTitleArea > #titleBox > .boxL').xpath('string()').get().strip()
        item['cheapest_value'] = re.search(r'\¥(\S*)', response.css('div.subInfoObj1 > p > span').xpath('string()').get()).group(1).replace(',', '')
        
        yield item